#pragma once

int check_basic_commands (int paramN, char* command[]);

void cmd_authors (int paramN, char* params[]);
void cmd_pid (int paramN, char* params[]);
void cmd_chdir  (int paramN, char* params[]);
void cmd_date  (int paramN, char* params[]);
void cmd_time (int paramN, char* params[]);
void cmd_infosys (int paramN, char* params[]);
void cmd_quit (int paramN, char* params[]);
