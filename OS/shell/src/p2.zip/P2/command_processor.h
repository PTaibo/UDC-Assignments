#pragma once

void processCommand (char* line);
