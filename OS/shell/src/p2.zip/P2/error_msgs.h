#pragma once

#include <stdio.h>

void invalid_param();
void missing_param();
void mem_fail();
void cannot_open_dir();
void cannot_open_file();
