#pragma once

// Check if a command is implemented in the file
int check_stat_commands(int paramN, char* command[]);

void cmd_stat(int paramN, char* params[]);
void cmd_list(int paramN, char* params[]);
